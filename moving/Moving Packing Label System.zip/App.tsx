import React, { useState, useEffect } from 'react';
import { LabelMaker } from './components/LabelMaker';
import { ItemManager } from './components/ItemManager';
import { SpreadsheetView } from './components/SpreadsheetView';
import { GoogleSheetsSync } from './components/GoogleSheetsSync';
import { Button } from './components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './components/ui/tabs';
import { Package, QrCode, Table, Plus, Download, Upload, Trash2, Cloud } from 'lucide-react';

export interface BoxItem {
  id: string;
  name: string;
  description?: string;
  category?: string;
  fragile?: boolean;
  image?: string;
}

export interface Box {
  id: string;
  name: string;
  color: string;
  room: string;
  boxNumber?: string;
  items: BoxItem[];
  qrCode: string;
  createdAt: Date;
}

export default function App() {
  const [boxes, setBoxes] = useState<Box[]>([]);
  const [activeTab, setActiveTab] = useState('labels');
  const [lastSaved, setLastSaved] = useState<Date | null>(null);
  const [googleSheetsConnected, setGoogleSheetsConnected] = useState(false);

  // Load boxes from localStorage on mount
  useEffect(() => {
    const savedBoxes = localStorage.getItem('movingBoxes');
    if (savedBoxes) {
      try {
        const parsedBoxes = JSON.parse(savedBoxes);
        setBoxes(parsedBoxes.map((box: any) => ({
          ...box,
          createdAt: new Date(box.createdAt)
        })));
      } catch (error) {
        console.error('Error loading boxes:', error);
      }
    }
  }, []);

  // Save boxes to localStorage whenever boxes change
  useEffect(() => {
    localStorage.setItem('movingBoxes', JSON.stringify(boxes));
    setLastSaved(new Date());
  }, [boxes]);

  const addBox = (box: Omit<Box, 'id' | 'createdAt'>) => {
    const newBox: Box = {
      ...box,
      id: Date.now().toString(),
      createdAt: new Date()
    };
    setBoxes(prev => [...prev, newBox]);
  };

  const updateBox = (boxId: string, updates: Partial<Box>) => {
    setBoxes(prev => prev.map(box => 
      box.id === boxId ? { ...box, ...updates } : box
    ));
  };

  const deleteBox = (boxId: string) => {
    setBoxes(prev => prev.filter(box => box.id !== boxId));
  };

  const addItemToBox = (boxId: string, item: Omit<BoxItem, 'id'>) => {
    const newItem: BoxItem = {
      ...item,
      id: Date.now().toString()
    };
    
    setBoxes(prev => prev.map(box => 
      box.id === boxId 
        ? { ...box, items: [...box.items, newItem] }
        : box
    ));
  };

  const removeItemFromBox = (boxId: string, itemId: string) => {
    setBoxes(prev => prev.map(box => 
      box.id === boxId 
        ? { ...box, items: box.items.filter(item => item.id !== itemId) }
        : box
    ));
  };

  // Clear all data (useful for testing or starting fresh)
  const clearAllData = () => {
    if (window.confirm('Are you sure you want to delete all boxes and items? This action cannot be undone.')) {
      setBoxes([]);
      localStorage.removeItem('movingBoxes');
      setLastSaved(null);
    }
  };

  // Export data as JSON (for backup)
  const exportData = () => {
    const dataStr = JSON.stringify(boxes, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `moving-data-${new Date().toISOString().split('T')[0]}.json`;
    link.click();
    URL.revokeObjectURL(url);
  };

  // Import data from JSON or CSV file
  const importData = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        const content = e.target?.result as string;
        const fileName = file.name.toLowerCase();
        
        try {
          if (fileName.endsWith('.json')) {
            // Handle JSON import
            const jsonData = JSON.parse(content);
            // Validate the data structure
            if (Array.isArray(jsonData) && jsonData.every(box => 
              box.id && box.name && box.color && box.room && Array.isArray(box.items)
            )) {
              const restoredBoxes = jsonData.map(box => ({
                ...box,
                createdAt: new Date(box.createdAt || Date.now())
              }));
              setBoxes(restoredBoxes);
              setLastSaved(new Date());
              alert('JSON data imported successfully!');
            } else {
              alert('Invalid JSON format. Please select a valid Moving Labels data file.');
            }
          } else if (fileName.endsWith('.csv')) {
            // Handle CSV import
            const lines = content.split('\n').filter(line => line.trim());
            if (lines.length === 0) {
              alert('CSV file is empty.');
              return;
            }
            
            // Parse CSV header - handle quoted values properly
            const parseCSVLine = (line: string): string[] => {
              const result: string[] = [];
              let current = '';
              let inQuotes = false;
              
              for (let i = 0; i < line.length; i++) {
                const char = line[i];
                if (char === '"') {
                  inQuotes = !inQuotes;
                } else if (char === ',' && !inQuotes) {
                  result.push(current.trim());
                  current = '';
                } else {
                  current += char;
                }
              }
              result.push(current.trim());
              return result;
            };
            
            const headers = parseCSVLine(lines[0]);
            console.log('Parsed headers:', headers);
            
            // Expected CSV format matches export: Item Name,Description,Category,Fragile,Box Name,Box Number,Room,Box Color,Has Image
            const requiredHeaders = ['Item Name', 'Box Name', 'Room', 'Box Color'];
            const hasRequiredHeaders = requiredHeaders.every(header => 
              headers.includes(header)
            );
            
            console.log('Required headers:', requiredHeaders);
            console.log('Has required headers:', hasRequiredHeaders);
            console.log('Missing headers:', requiredHeaders.filter(header => !headers.includes(header)));
            
            if (!hasRequiredHeaders) {
              alert(`CSV must contain at least: Item Name, Box Name, Room, and Box Color columns.\n\nFound headers: ${headers.join(', ')}\n\nMissing: ${requiredHeaders.filter(header => !headers.includes(header)).join(', ')}`);
              return;
            }
            
            // Parse data rows
            const boxMap = new Map<string, Box>();
            
            for (let i = 1; i < lines.length; i++) {
              const values = parseCSVLine(lines[i]);
              if (values.length < headers.length) continue;
              
              const row: { [key: string]: string } = {};
              headers.forEach((header, index) => {
                row[header] = values[index] || '';
              });
              
              // Extract box information (exact header matches)
              const boxName = row['Box Name'] || '';
              const room = row['Room'] || '';
              const boxColor = row['Box Color'] || '#3b82f6';
              const boxNumber = row['Box Number'] || '';
              
              if (!boxName || !room) continue;
              
              // Create unique box key
              const boxKey = `${boxName}-${room}`;
              
              if (!boxMap.has(boxKey)) {
                const newBox: Box = {
                  id: `imported-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
                  name: boxName,
                  color: boxColor.startsWith('#') ? boxColor : '#3b82f6',
                  room: room,
                  boxNumber: boxNumber || undefined,
                  items: [],
                  qrCode: `${window.location.origin}?box=imported-${Date.now()}`,
                  createdAt: new Date()
                };
                boxMap.set(boxKey, newBox);
              }
              
              // Add item to box if item name exists
              const itemName = row['Item Name'] || '';
              if (itemName) {
                const item: BoxItem = {
                  id: `item-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
                  name: itemName,
                  description: row['Description'] || undefined,
                  category: row['Category'] || undefined,
                  fragile: (row['Fragile'] || '').toLowerCase() === 'yes'
                };
                
                boxMap.get(boxKey)?.items.push(item);
              }
            }
            
            if (boxMap.size === 0) {
              alert('No valid data found in CSV file.');
              return;
            }
            
            const importedBoxes = Array.from(boxMap.values());
            setBoxes(prev => [...prev, ...importedBoxes]);
            setLastSaved(new Date());
            alert(`CSV data imported successfully! Added ${importedBoxes.length} boxes with ${importedBoxes.reduce((sum, box) => sum + box.items.length, 0)} items.`);
          } else {
            alert('Unsupported file type. Please select a JSON or CSV file.');
          }
        } catch (error) {
          console.error('Import error:', error);
          alert(`Error reading file: ${error instanceof Error ? error.message : 'Unknown error'}. Please make sure it's a valid JSON or CSV file.`);
        }
      };
      reader.readAsText(file);
    }
    
    // Reset the input value so the same file can be selected again
    event.target.value = '';
  };

  // Import boxes from Google Sheets or other sources
  const importBoxes = (newBoxes: Box[]) => {
    setBoxes(newBoxes);
    setLastSaved(new Date());
  };

  // Check Google Sheets connection status on mount
  useEffect(() => {
    const syncStatus = localStorage.getItem('googleSheetsSyncStatus');
    if (syncStatus) {
      try {
        const status = JSON.parse(syncStatus);
        setGoogleSheetsConnected(status.connected || false);
      } catch (error) {
        console.error('Error parsing Google Sheets sync status:', error);
      }
    }
  }, []);

  // Listen for Google Sheets connection changes
  useEffect(() => {
    const handleStorageChange = () => {
      const syncStatus = localStorage.getItem('googleSheetsSyncStatus');
      if (syncStatus) {
        try {
          const status = JSON.parse(syncStatus);
          setGoogleSheetsConnected(status.connected || false);
        } catch (error) {
          console.error('Error parsing Google Sheets sync status:', error);
        }
      } else {
        setGoogleSheetsConnected(false);
      }
    };

    window.addEventListener('storage', handleStorageChange);
    return () => window.removeEventListener('storage', handleStorageChange);
  }, []);

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Package className="h-8 w-8 text-blue-600" />
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Moving Labels</h1>
                <p className="text-sm text-gray-600">Organize your move with color-coded labels and QR codes</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <div className="text-sm text-gray-500">
                <div className="flex items-center space-x-2">
                  <span>{boxes.length} boxes created</span>
                  {googleSheetsConnected && (
                    <span className="flex items-center space-x-1 text-green-600">
                      <Cloud className="h-3 w-3" />
                      <span className="text-xs">Synced</span>
                    </span>
                  )}
                </div>
                {lastSaved && (
                  <div className="text-xs text-green-600">
                    Last saved: {lastSaved.toLocaleTimeString()}
                  </div>
                )}
              </div>
              <div className="flex items-center space-x-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={exportData}
                  className="flex items-center space-x-1"
                >
                  <Download className="h-4 w-4" />
                  <span>Export</span>
                </Button>
                <div className="relative">
                  <input
                    type="file"
                    accept=".json,.csv"
                    onChange={importData}
                    className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                    id="import-file"
                  />
                  <label 
                    htmlFor="import-file" 
                    className="inline-flex items-center justify-center rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 border border-input bg-background hover:bg-accent hover:text-accent-foreground h-9 px-3 cursor-pointer space-x-1"
                    title="Import JSON or CSV files"
                  >
                    <Upload className="h-4 w-4" />
                    <span>Import</span>
                  </label>
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={clearAllData}
                  className="flex items-center space-x-1 text-red-600 hover:text-red-700"
                >
                  <Trash2 className="h-4 w-4" />
                  <span>Clear All</span>
                </Button>
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-4 mb-8">
            <TabsTrigger value="labels" className="flex items-center space-x-2">
              <Package className="h-4 w-4" />
              <span>Create Labels</span>
            </TabsTrigger>
            <TabsTrigger value="items" className="flex items-center space-x-2">
              <QrCode className="h-4 w-4" />
              <span>Manage Items</span>
            </TabsTrigger>
            <TabsTrigger value="spreadsheet" className="flex items-center space-x-2">
              <Table className="h-4 w-4" />
              <span>View All Items</span>
            </TabsTrigger>
            <TabsTrigger value="sync" className="flex items-center space-x-2">
              <Cloud className="h-4 w-4" />
              <span>Google Sheets</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="labels">
            <LabelMaker 
              boxes={boxes}
              onAddBox={addBox}
              onUpdateBox={updateBox}
              onDeleteBox={deleteBox}
            />
          </TabsContent>

          <TabsContent value="items">
            <ItemManager 
              boxes={boxes}
              onAddItem={addItemToBox}
              onRemoveItem={removeItemFromBox}
              onUpdateBox={updateBox}
            />
          </TabsContent>

          <TabsContent value="spreadsheet">
            <SpreadsheetView boxes={boxes} />
          </TabsContent>

          <TabsContent value="sync">
            <GoogleSheetsSync 
              boxes={boxes}
              onImportBoxes={importBoxes}
            />
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}