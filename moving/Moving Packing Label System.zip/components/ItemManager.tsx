import React, { useState, useMemo } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Checkbox } from './ui/checkbox';
import { Badge } from './ui/badge';
import { Trash2, Plus, Package, AlertTriangle, Search, Filter, X, Edit3, Hash, Image as ImageIcon } from 'lucide-react';
import { Box, BoxItem } from '../App';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface ItemManagerProps {
  boxes: Box[];
  onAddItem: (boxId: string, item: Omit<BoxItem, 'id'>) => void;
  onRemoveItem: (boxId: string, itemId: string) => void;
  onUpdateBox: (boxId: string, updates: Partial<Box>) => void;
}

const CATEGORIES = [
  'Electronics', 'Clothing', 'Books', 'Kitchen', 'Fragile', 'Documents', 'Toys', 'Tools', 'Other'
];

export function ItemManager({ boxes, onAddItem, onRemoveItem, onUpdateBox }: ItemManagerProps) {
  const [selectedBoxId, setSelectedBoxId] = useState('');
  const [newItem, setNewItem] = useState({
    name: '',
    description: '',
    category: '',
    fragile: false,
    image: ''
  });
  const [editingBoxNumber, setEditingBoxNumber] = useState<string | null>(null);
  const [boxNumberInput, setBoxNumberInput] = useState('');
  const [imagePreview, setImagePreview] = useState<string | null>(null);

  // Filter states
  const [filters, setFilters] = useState({
    search: '',
    room: '',
    category: '',
    fragileOnly: false,
    showEmpty: true,
    noBoxNumber: false
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedBoxId || !newItem.name.trim()) return;

    onAddItem(selectedBoxId, {
      name: newItem.name.trim(),
      description: newItem.description.trim() || undefined,
      category: newItem.category || undefined,
      fragile: newItem.fragile,
      image: newItem.image || undefined
    });

    setNewItem({ name: '', description: '', category: '', fragile: false, image: '' });
    setImagePreview(null);
  };

  const handleBoxNumberEdit = (boxId: string) => {
    const box = boxes.find(b => b.id === boxId);
    setEditingBoxNumber(boxId);
    setBoxNumberInput(box?.boxNumber || '');
  };

  const handleBoxNumberSave = (boxId: string) => {
    onUpdateBox(boxId, { boxNumber: boxNumberInput.trim() || undefined });
    setEditingBoxNumber(null);
    setBoxNumberInput('');
  };

  const handleBoxNumberCancel = () => {
    setEditingBoxNumber(null);
    setBoxNumberInput('');
  };

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      // Check file size (limit to 5MB)
      if (file.size > 5 * 1024 * 1024) {
        alert('Image size must be less than 5MB');
        return;
      }

      // Check file type
      if (!file.type.startsWith('image/')) {
        alert('Please select a valid image file');
        return;
      }

      const reader = new FileReader();
      reader.onload = (e) => {
        const base64String = e.target?.result as string;
        setNewItem(prev => ({ ...prev, image: base64String }));
        setImagePreview(base64String);
      };
      reader.readAsDataURL(file);
    }
  };

  const removeImage = () => {
    setNewItem(prev => ({ ...prev, image: '' }));
    setImagePreview(null);
  };

  const selectedBox = boxes.find(box => box.id === selectedBoxId);

  // Get unique values for filter dropdowns
  const uniqueRooms = useMemo(() => 
    [...new Set(boxes.map(box => box.room))].sort(), 
    [boxes]
  );

  const uniqueCategories = useMemo(() => 
    [...new Set(boxes.flatMap(box => box.items.map(item => item.category)).filter(Boolean))].sort(), 
    [boxes]
  );

  // Filtered boxes for overview section
  const filteredBoxes = useMemo(() => {
    return boxes.filter(box => {
      // Room filter
      if (filters.room && box.room !== filters.room) return false;
      
      // Empty boxes filter
      if (!filters.showEmpty && box.items.length === 0) return false;
      
      // Search filter (box name, room, box number, or item names)
      if (filters.search) {
        const searchLower = filters.search.toLowerCase();
        const matchesBox = box.name.toLowerCase().includes(searchLower) || 
                          box.room.toLowerCase().includes(searchLower) ||
                          (box.boxNumber && box.boxNumber.toLowerCase().includes(searchLower));
        const matchesItems = box.items.some(item => 
          item.name.toLowerCase().includes(searchLower) ||
          (item.description && item.description.toLowerCase().includes(searchLower))
        );
        if (!matchesBox && !matchesItems) return false;
      }
      
      // Category filter (at least one item must match)
      if (filters.category) {
        const hasMatchingCategory = box.items.some(item => item.category === filters.category);
        if (!hasMatchingCategory) return false;
      }
      
      // Fragile filter (at least one fragile item)
      if (filters.fragileOnly) {
        const hasFragileItems = box.items.some(item => item.fragile);
        if (!hasFragileItems) return false;
      }
      
      // No box number filter
      if (filters.noBoxNumber) {
        if (box.boxNumber && box.boxNumber.trim()) return false;
      }
      
      return true;
    });
  }, [boxes, filters]);

  const clearFilters = () => {
    setFilters({
      search: '',
      room: '',
      category: '',
      fragileOnly: false,
      showEmpty: true,
      noBoxNumber: false
    });
  };

  const hasActiveFilters = filters.search || filters.room || filters.category || filters.fragileOnly || !filters.showEmpty || filters.noBoxNumber;

  return (
    <div className="space-y-8">
      {/* Add Items Form */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Plus className="h-5 w-5" />
            <span>Add Items to Box</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          {boxes.length === 0 ? (
            <div className="text-center py-8">
              <Package className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-500">No boxes available. Create a box label first!</p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="box-select">Select Box</Label>
                <Select value={selectedBoxId} onValueChange={setSelectedBoxId}>
                  <SelectTrigger>
                    <SelectValue placeholder="Choose a box to add items to" />
                  </SelectTrigger>
                  <SelectContent>
                    {boxes.map(box => (
                      <SelectItem key={box.id} value={box.id}>
                        <div className="flex items-center space-x-2">
                          <div 
                            className="w-3 h-3 rounded-full" 
                            style={{ background: box.color }}
                          />
                          <span>{box.name} ({box.room})</span>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {selectedBoxId && (
                <>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="item-name">Item Name</Label>
                      <Input
                        id="item-name"
                        value={newItem.name}
                        onChange={(e) => setNewItem(prev => ({ ...prev, name: e.target.value }))}
                        placeholder="e.g., Coffee Maker"
                        required
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="category">Category</Label>
                      <Select value={newItem.category} onValueChange={(value) => setNewItem(prev => ({ ...prev, category: value }))}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select category" />
                        </SelectTrigger>
                        <SelectContent>
                          {CATEGORIES.map(category => (
                            <SelectItem key={category} value={category}>{category}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="description">Description (Optional)</Label>
                    <Input
                      id="description"
                      value={newItem.description}
                      onChange={(e) => setNewItem(prev => ({ ...prev, description: e.target.value }))}
                      placeholder="Additional details about the item"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="item-image">Image (Optional)</Label>
                    <div className="space-y-2">
                      <Input
                        id="item-image"
                        type="file"
                        accept="image/*"
                        onChange={handleImageUpload}
                        className="cursor-pointer"
                      />
                      {imagePreview && (
                        <div className="relative inline-block">
                          <img
                            src={imagePreview}
                            alt="Item preview"
                            className="w-20 h-20 object-cover rounded-md border"
                          />
                          <Button
                            type="button"
                            variant="ghost"
                            size="sm"
                            onClick={removeImage}
                            className="absolute -top-2 -right-2 w-5 h-5 p-0 rounded-full bg-red-500 text-white hover:bg-red-600"
                          >
                            <X className="h-3 w-3" />
                          </Button>
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="fragile"
                      checked={newItem.fragile}
                      onCheckedChange={(checked) => setNewItem(prev => ({ ...prev, fragile: !!checked }))}
                    />
                    <Label htmlFor="fragile" className="flex items-center space-x-1">
                      <AlertTriangle className="h-4 w-4 text-orange-500" />
                      <span>Fragile item</span>
                    </Label>
                  </div>

                  <Button type="submit" className="w-full">
                    <Plus className="h-4 w-4 mr-2" />
                    Add Item
                  </Button>
                </>
              )}
            </form>
          )}
        </CardContent>
      </Card>

      {/* Box Contents */}
      {selectedBox && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <div 
                className="w-5 h-5 rounded-full" 
                style={{ background: selectedBox.color }}
              />
              <span>{selectedBox.name} Contents</span>
              <Badge variant="secondary">{selectedBox.items.length} items</Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            {selectedBox.items.length === 0 ? (
              <p className="text-gray-500 text-center py-4">No items added to this box yet.</p>
            ) : (
              <div className="space-y-2">
                {selectedBox.items.map(item => (
                  <div key={item.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div className="flex items-center space-x-3 flex-1">
                      {item.image && (
                        <img
                          src={item.image}
                          alt={item.name}
                          className="w-12 h-12 object-cover rounded-md border"
                        />
                      )}
                      <div className="flex-1">
                        <div className="flex items-center space-x-2">
                          <span className="font-medium">{item.name}</span>
                          {item.fragile && (
                            <AlertTriangle className="h-4 w-4 text-orange-500" title="Fragile" />
                          )}
                          {item.category && (
                            <Badge variant="outline" className="text-xs">
                              {item.category}
                            </Badge>
                          )}
                        </div>
                        {item.description && (
                          <p className="text-sm text-gray-600 mt-1">{item.description}</p>
                        )}
                      </div>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => onRemoveItem(selectedBox.id, item.id)}
                      className="text-red-500 hover:text-red-700"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* All Boxes Overview */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-semibold">All Boxes Overview</h2>
          <Badge variant="secondary">
            {filteredBoxes.length} of {boxes.length} boxes
          </Badge>
        </div>

        {/* Filters */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Filter className="h-5 w-5" />
              <span>Filters</span>
              {hasActiveFilters && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={clearFilters}
                  className="ml-auto text-xs"
                >
                  <X className="h-3 w-3 mr-1" />
                  Clear All
                </Button>
              )}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {/* Search */}
              <div className="space-y-2">
                <Label htmlFor="search">Search</Label>
                <div className="relative">
                  <Search className="absolute left-2 top-2.5 h-4 w-4 text-gray-400" />
                  <Input
                    id="search"
                    placeholder="Search boxes, items, or box numbers..."
                    value={filters.search}
                    onChange={(e) => setFilters(prev => ({ ...prev, search: e.target.value }))}
                    className="pl-8"
                  />
                </div>
              </div>

              {/* Room Filter */}
              <div className="space-y-2">
                <Label htmlFor="room-filter">Room</Label>
                <Select value={filters.room || 'all-rooms'} onValueChange={(value) => setFilters(prev => ({ ...prev, room: value === 'all-rooms' ? '' : value }))}>
                  <SelectTrigger>
                    <SelectValue placeholder="All rooms" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all-rooms">All rooms</SelectItem>
                    {uniqueRooms.map(room => (
                      <SelectItem key={room} value={room}>{room}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Category Filter */}
              <div className="space-y-2">
                <Label htmlFor="category-filter">Category</Label>
                <Select value={filters.category || 'all-categories'} onValueChange={(value) => setFilters(prev => ({ ...prev, category: value === 'all-categories' ? '' : value }))}>
                  <SelectTrigger>
                    <SelectValue placeholder="All categories" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all-categories">All categories</SelectItem>
                    {uniqueCategories.map(category => (
                      <SelectItem key={category} value={category}>{category}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Additional Filters */}
              <div className="space-y-3">
                <Label>Options</Label>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="fragile-only"
                      checked={filters.fragileOnly}
                      onCheckedChange={(checked) => setFilters(prev => ({ ...prev, fragileOnly: !!checked }))}
                    />
                    <Label htmlFor="fragile-only" className="text-sm">
                      Fragile items only
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="show-empty"
                      checked={filters.showEmpty}
                      onCheckedChange={(checked) => setFilters(prev => ({ ...prev, showEmpty: !!checked }))}
                    />
                    <Label htmlFor="show-empty" className="text-sm">
                      Show empty boxes
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="no-box-number"
                      checked={filters.noBoxNumber}
                      onCheckedChange={(checked) => setFilters(prev => ({ ...prev, noBoxNumber: !!checked }))}
                    />
                    <Label htmlFor="no-box-number" className="text-sm">
                      No box number only
                    </Label>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Filter Summary */}
        {hasActiveFilters && filteredBoxes.length > 0 && (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
            <Card>
              <CardContent className="pt-6">
                <div className="text-2xl font-bold">{filteredBoxes.length}</div>
                <p className="text-xs text-muted-foreground">Boxes Found</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <div className="text-2xl font-bold">
                  {filteredBoxes.reduce((sum, box) => sum + box.items.length, 0)}
                </div>
                <p className="text-xs text-muted-foreground">Total Items</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <div className="text-2xl font-bold text-orange-600">
                  {filteredBoxes.reduce((sum, box) => sum + box.items.filter(item => item.fragile).length, 0)}
                </div>
                <p className="text-xs text-muted-foreground">Fragile Items</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <div className="text-2xl font-bold">
                  {filteredBoxes.filter(box => box.items.length === 0).length}
                </div>
                <p className="text-xs text-muted-foreground">Empty Boxes</p>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Results */}
        {filteredBoxes.length === 0 ? (
          <Card>
            <CardContent className="text-center py-8">
              <Package className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-500">
                {hasActiveFilters ? 'No boxes match your filters.' : 'No boxes found.'}
              </p>
              {hasActiveFilters && (
                <Button variant="outline" onClick={clearFilters} className="mt-2">
                  Clear Filters
                </Button>
              )}
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredBoxes.map(box => (
              <Card 
                key={box.id} 
                className={`cursor-pointer transition-all ${
                  selectedBoxId === box.id ? 'ring-2 ring-blue-500' : 'hover:shadow-md'
                }`}
                onClick={() => setSelectedBoxId(box.id)}
              >
                <CardHeader className="pb-3">
                  <CardTitle className="flex items-center space-x-2 text-lg">
                    <div 
                      className="w-4 h-4 rounded-full" 
                      style={{ background: box.color }}
                    />
                    <span>{box.name}</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Room:</span>
                      <Badge variant="secondary">{box.room}</Badge>
                    </div>
                    <div className="flex justify-between" onClick={(e) => e.stopPropagation()}>
                      <span className="text-gray-600">Box Number:</span>
                      <div className="flex items-center space-x-1">
                        {editingBoxNumber === box.id ? (
                          <div className="flex items-center space-x-1">
                            <Input
                              value={boxNumberInput}
                              onChange={(e) => setBoxNumberInput(e.target.value)}
                              placeholder="e.g., 001"
                              className="w-16 h-6 text-xs"
                              onKeyDown={(e) => {
                                if (e.key === 'Enter') handleBoxNumberSave(box.id);
                                if (e.key === 'Escape') handleBoxNumberCancel();
                              }}
                              autoFocus
                            />
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => handleBoxNumberSave(box.id)}
                              className="h-5 w-5 p-0 text-xs"
                            >
                              ✓
                            </Button>
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={handleBoxNumberCancel}
                              className="h-5 w-5 p-0 text-xs"
                            >
                              ✕
                            </Button>
                          </div>
                        ) : (
                          <div className="flex items-center space-x-1">
                            <span className="text-sm">
                              {box.boxNumber || 'None'}
                            </span>
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => handleBoxNumberEdit(box.id)}
                              className="h-4 w-4 p-0 text-gray-400 hover:text-gray-600"
                            >
                              <Edit3 className="h-3 w-3" />
                            </Button>
                          </div>
                        )}
                      </div>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Items:</span>
                      <span>{box.items.length}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Fragile Items:</span>
                      <span className="text-orange-600">
                        {box.items.filter(item => item.fragile).length}
                      </span>
                    </div>
                    {box.items.length > 0 && (
                      <div className="pt-2 border-t">
                        <div className="flex flex-wrap gap-1">
                          {[...new Set(box.items.map(item => item.category).filter(Boolean))].map(category => (
                            <Badge key={category} variant="outline" className="text-xs">
                              {category}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}